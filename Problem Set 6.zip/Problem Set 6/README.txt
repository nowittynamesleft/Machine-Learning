Answers to questions are in AnswersToQuestions.pdf. Use python to run bagofwords.py on warandpeace.txt in this way:

python bagofwords.py warandpeace.txt


