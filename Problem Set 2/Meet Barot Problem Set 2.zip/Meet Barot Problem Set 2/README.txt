Run python3 setofwords.py to see the test errors for different values of
lambda.

Solutions.pdf contains the answers to the written questions and the plots.
