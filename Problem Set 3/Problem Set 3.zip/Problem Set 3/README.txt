Use python3 to run problemset3.py, answers to the questions are in the pdf. The graph for part 3 was not included because
each lambda produced the same cross-validation error as the last, the graph was just a straight line.

Sci-kit learn's svc gave repeated deprecation warnings because I had passed in a singly-dimensional array
for the classification list. However, the values for validation and test errors  are still produced at the end of the program.
