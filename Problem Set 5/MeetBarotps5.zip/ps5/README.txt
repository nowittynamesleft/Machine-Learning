Use python3 to run ps5.py. The output is the dendogram for 30 randomly selected foods from each food group.
After the plot is displayed, you must press enter in the terminal to continue the program.

Answers to questions 3, 4, 5, 6, and 7 are in ps5questionsandplot.pdf.

A dendogram for one random sample of 30 foods from each food group is included in the pdf.

The data used is included in the same directory as all the other files.
